# Apples are red.
# Oranges are orange.
# Blueberries are delicious.