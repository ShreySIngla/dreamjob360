# Apples are obviously red.
# Oranges are NOT blue.
# Blueberries are delicious.