# Apples are obviously red.
# Oranges are blue.
# Blueberries are delicious.