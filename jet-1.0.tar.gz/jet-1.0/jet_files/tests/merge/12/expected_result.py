# Apples are obviously red.
# @@@@@@@@@@HEAD@@@@@@@@@@
# Oranges are blue.
# @@@@@@@@@@SEPARATOR@@@@@@@@@@
# Oranges are NOT blue.
# @@@@@@@@@@END@@@@@@@@@@
# Blueberries are delicious.