print "1213"


print "sdna"

print "213--=+++"

print "   )))3---"