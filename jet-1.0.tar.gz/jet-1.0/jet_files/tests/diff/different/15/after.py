print "124121"

print "  (()))))"

print "  ++++3334141"
