

print "Bfdsjb fdjs"


print "BNJkvsbvkdbjsk"




print "Njkvskvd"