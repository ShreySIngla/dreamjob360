

print "sdcdbnajksdb"






print "snjkanks"




print "scbjkabsck"