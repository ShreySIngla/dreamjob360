print "Test"
print "Test"