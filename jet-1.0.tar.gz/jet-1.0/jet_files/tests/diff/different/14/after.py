print "  hedhfjsd"
print "dsnksdj"
print "        sdknadjsa"

print "     sdabdsa"
print "    assaxc"