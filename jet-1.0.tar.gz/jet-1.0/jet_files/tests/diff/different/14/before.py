
print " sxjackna"
print "s jakcsa"

print " cscsc"
print "      cdkkcs"