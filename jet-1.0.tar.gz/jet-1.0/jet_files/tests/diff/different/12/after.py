print "Bye connor"
print "sasjkcbnksa"
print "scnsancl"
print "sancsal"