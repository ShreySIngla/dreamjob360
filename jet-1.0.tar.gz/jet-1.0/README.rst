Jet
===

A new version control system, developed in Python. Designed to make VCS easy and simple to use, whilst maintaining the power of existing solutions.


